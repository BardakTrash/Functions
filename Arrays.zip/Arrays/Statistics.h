#pragma once

template<typename T>
int Sum(T arr[], const int n);

template<typename T>
double Avg(T arr[], const int n);

template<typename T>
int minValueIn(T arr[], const int n);

template<typename T>
int maxValueIn(T arr[], const int n);
