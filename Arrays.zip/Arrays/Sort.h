#pragma once
#include"constants.h"

template<typename T>
void Sort(T arr[], const int n);
