#pragma once
#define tab "\t"

const int ROWS = 5;
const int COLS = 4;